#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<i;j++)
        {
          if(i%2==1) printf("%d",(n+j)%2);
          else printf("%d",(n+j+1)%2);
        }
        printf("\n");
    }
}