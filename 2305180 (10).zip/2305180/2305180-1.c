#include<stdio.h>
#include<limits.h>
int main()
{
    int n,a,s=0,even=0,odd=0;
    int max= INT_MIN;
    int min =INT_MAX;
    printf("How many numbers do you want to enter? ");
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a);
        if(a>max) max=a;
        if(a<min) min =a;
        s +=a;
        if(a%2==0) even++;
        else odd++;

    }
    printf("Minimum Number: %d \nMaximum Number:%d\nSum of all numbers: %d \nAverage: %f\nEven number count: %d\nOdd Number count: %d",min,max,s,(float)s/n,even,odd);

}